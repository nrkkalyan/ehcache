package com.howtodoinjava.demo;

import java.util.Arrays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

//https://www.ehcache.org/documentation/2.8/replication/rmi-replicated-caching.html#configuring-the-peer-provider
@SpringBootApplication
@EnableCaching
public class Application {
	
	public static final String GROUP_ADDRESS = "ehcache.rmi.groupAddress";
	public static final String GROUP_PORT = "ehcache.rmi.groupPort";

	
	public static void main(String[] args) {

//		System.setProperty(GROUP_ADDRESS, args[1].trim());
//		System.setProperty(GROUP_PORT, args[2].trim());
		
		SpringApplication.run(Application.class, args);
		
	}
	 
}
