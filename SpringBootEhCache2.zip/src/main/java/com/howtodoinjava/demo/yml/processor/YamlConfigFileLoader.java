package com.howtodoinjava.demo.yml.processor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Queue;
import java.util.Set;
import java.util.stream.StreamSupport;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.*;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.context.support.StandardServletEnvironment;

public class YamlConfigFileLoader {

	private static final Logger log = LoggerFactory.getLogger(YamlConfigFileLoader.class);

	private static final String DEFAULT_PROPERTIES = "defaultProperties";

	private static final String DEFAULT_NAMES = "application";

	/**
	 * The "active profiles" property name.
	 */
	public static final String ACTIVE_PROFILES_PROPERTY = "spring.profiles.active";

	/**
	 * The "includes profiles" property name.
	 */
	public static final String INCLUDE_PROFILES_PROPERTY = "spring.profiles.include";

	/**
	 * The "config name" property name.
	 */
	public static final String CONFIG_NAME_PROPERTY = "spring.config.name";

	/**
	 * The "config location" property name.
	 */
	public static final String CONFIG_LOCATION_PROPERTY = "spring.config.location";

	private static final String[] WEB_ENVIRONMENT_CLASSES = { "javax.servlet.Servlet",
			"org.springframework.web.context.ConfigurableWebApplicationContext" };

	private List<String> processedProfiles;
	private PropertySourcesLoader propertiesLoader;
	private final ConfigurableEnvironment environment;
	private boolean activatedProfiles;
	private Queue<String> profiles;

	public YamlConfigFileLoader() {
		this.environment = getOrCreateEnvironment();
		this.propertiesLoader = new PropertySourcesLoader();
		this.activatedProfiles = false;
		this.profiles = Collections.asLifoQueue(new LinkedList<String>());
		this.processedProfiles = new LinkedList<String>();
	}

	private ConfigurableEnvironment getOrCreateEnvironment() {
		if (this.environment != null) {
			return this.environment;
		}
		if (deduceWebEnvironment()) {
			return new StandardServletEnvironment();
		}
		return new StandardEnvironment();

	}

	private boolean deduceWebEnvironment() {
		for (String className : WEB_ENVIRONMENT_CLASSES) {
			if (!ClassUtils.isPresent(className, null)) {
				return false;
			}
		}
		return true;
	}

	public ConfigurableEnvironment load(final String[] profiles) throws IOException {

		load(DEFAULT_NAMES, null); // Load default profile to start with
		for (String profile : profiles) {
			load(DEFAULT_NAMES, profile);
			this.processedProfiles.add(profile);
		}

		addConfigurationProperties(this.propertiesLoader.getPropertySources());

		return this.environment;
	}

	public static Properties getProperties(final Environment environment) {
		final Properties props = new Properties();
		final MutablePropertySources propSrcs = ((ConfigurableEnvironment) environment).getPropertySources();
		StreamSupport.stream(propSrcs.spliterator(), false)
				.filter(ps -> ps instanceof ConfigurationPropertySources)
				.map(ps -> ((EnumerablePropertySource<?>) ps).getPropertyNames()).flatMap(Arrays::stream)
				.forEach(propName -> props.setProperty(propName, environment.getProperty(propName)));
		return props;
	}

	private void load(String name, String profile) throws IOException {
		String group = "profile=" + (profile == null ? "" : profile);
		// Search for a file with the given name
		for (String ext : YamlPropertySourceLoader.getFileExtensions()) {
			if (profile != null) {
				// Try the profile specific file
				loadIntoGroup(group, name + "-" + profile + "." + ext, null);
				for (String processedProfile : this.processedProfiles) {
					if (processedProfile != null) {
						loadIntoGroup(group, name + "-" + processedProfile + "." + ext, profile);
					}
				}
				// Sometimes people put "spring.profiles: dev" in
				// application-dev.yml (gh-340). Arguably we should try and error
				// out on that, but we can be kind and load it anyway.
				loadIntoGroup(group, name + "-" + profile + "." + ext, profile);
			}
			// Also try the profile specific section (if any) of the normal file
			loadIntoGroup(group, name + "." + ext, profile);
		}
	}

	private PropertySource<?> loadIntoGroup(String identifier, String location, String profile) throws IOException {
		Resource resource = new ClassPathResource(location);
		PropertySource<?> propertySource = null;
		if (resource != null && resource.exists()) {
			String name = "applicationConfig: [" + location + "]";
			String group = "applicationConfig: [" + identifier + "]";
			propertySource = this.propertiesLoader.load(resource, group, name, profile);
			if (propertySource != null) {
				handleProfileProperties(propertySource);
			}
		}

		return propertySource;
	}

	private void handleProfileProperties(PropertySource<?> propertySource) {
		Set<String> activeProfiles = getProfilesForValue(propertySource.getProperty(ACTIVE_PROFILES_PROPERTY));
		maybeActivateProfiles(activeProfiles);
		Set<String> includeProfiles = getProfilesForValue(propertySource.getProperty(INCLUDE_PROFILES_PROPERTY));
		addProfiles(includeProfiles);
	}

	private void maybeActivateProfiles(Set<String> profiles) {
		if (this.activatedProfiles) {
			return;
		}
		if (profiles.size() > 0) {
			addProfiles(profiles);
			log.info("Activated profiles :" + profiles);
			this.activatedProfiles = true;
		}
	}

	private void addProfiles(Set<String> profiles) {
		for (String profile : profiles) {
			this.profiles.add(profile);
			if (!this.environment.acceptsProfiles(Profiles.of(profile))) {
				// If it's already accepted we assume the order was set
				// intentionally
				prependProfile(profile);
			}
		}
	}

	private void prependProfile(String profile) {
		Set<String> profiles = new LinkedHashSet<String>();
		environment.getActiveProfiles(); // ensure they are initialized
		// But this one should go first (last wins in a property key clash)
		profiles.add(profile);
		profiles.addAll(Arrays.asList(environment.getActiveProfiles()));
		environment.setActiveProfiles(profiles.toArray(new String[profiles.size()]));
	}

	private Set<String> getProfilesForValue(Object property) {
		String value = (property == null ? null : property.toString());
		return asResolvedSet(value, null);
	}

	private Set<String> asResolvedSet(String value, String fallback) {
		List<String> list = Arrays.asList(StringUtils.commaDelimitedListToStringArray(
				value != null ? this.environment.resolvePlaceholders(value) : fallback));
		Collections.reverse(list);
		return new LinkedHashSet<String>(list);
	}

	private void addConfigurationProperties(MutablePropertySources sources) {
		List<PropertySource<?>> reorderedSources = new ArrayList<PropertySource<?>>();
		for (PropertySource<?> item : sources) {
			reorderedSources.add(item);
		}
		addConfigurationProperties(new ConfigurationPropertySources(reorderedSources));
	}

	private void addConfigurationProperties(ConfigurationPropertySources configurationSources) {
		MutablePropertySources existingSources = this.environment.getPropertySources();
		if (existingSources.contains(DEFAULT_PROPERTIES)) {
			existingSources.addBefore(DEFAULT_PROPERTIES, configurationSources);
		} else {
			existingSources.addLast(configurationSources);
		}
	}

	/**
	 * Holds the configuration {@link PropertySource}s as they are loaded can
	 * relocate them once configuration classes have been processed.
	 */
	public static class ConfigurationPropertySources extends EnumerablePropertySource<Collection<PropertySource<?>>> {

		private static final String NAME = "applicationConfigurationProperties";

		private final Collection<PropertySource<?>> sources;

		private final String[] names;

		ConfigurationPropertySources(Collection<PropertySource<?>> sources) {
			super(NAME, sources);
			this.sources = sources;
			List<String> names = new ArrayList<String>();
			for (PropertySource<?> source : sources) {
				if (source instanceof EnumerablePropertySource) {
					names.addAll(Arrays.asList(((EnumerablePropertySource<?>) source).getPropertyNames()));
				}
			}
			this.names = names.toArray(new String[names.size()]);
		}

		@Override
		public Object getProperty(String name) {
			for (PropertySource<?> propertySource : this.sources) {
				Object value = propertySource.getProperty(name);
				if (value != null) {
					return value;
				}
			}
			return null;
		}

		public static void finishAndRelocate(MutablePropertySources propertySources) {
			ConfigurationPropertySources removed = (ConfigurationPropertySources) propertySources
					.get(ConfigurationPropertySources.NAME);
			String name = ConfigurationPropertySources.NAME;
			if (removed != null) {
				for (PropertySource<?> propertySource : removed.sources) {
					if (propertySource instanceof EnumerableCompositePropertySource) {
						EnumerableCompositePropertySource composite = (EnumerableCompositePropertySource) propertySource;
						for (PropertySource<?> nested : composite.getSource()) {
							propertySources.addAfter(name, nested);
							name = nested.getName();
						}
					} else {
						propertySources.addAfter(name, propertySource);
					}
				}
				propertySources.remove(ConfigurationPropertySources.NAME);
			}
		}

		@Override
		public String[] getPropertyNames() {
			return this.names;
		}

	}
}
