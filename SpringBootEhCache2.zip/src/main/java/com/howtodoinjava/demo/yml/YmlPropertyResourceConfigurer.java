package com.howtodoinjava.demo.yml;

import java.io.IOException;
import java.util.Properties;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.howtodoinjava.demo.yml.processor.YamlConfigFileLoader;

import lombok.extern.slf4j.Slf4j;


@Slf4j
public class YmlPropertyResourceConfigurer extends PropertyPlaceholderConfigurer {

    private static Properties ymlProperties;
    private static ConfigurableEnvironment environment;


    @Override
    protected void loadProperties(Properties props) throws IOException {
        props.putAll(getProperties());
        super.loadProperties(props);
    }

    public static Properties getProperties() {
        final Resource resource = new ClassPathResource("application.yml");
        if (resource == null || !resource.exists()) {
            return new Properties();
        }

        if (ymlProperties == null) {
            getEnvironment();
            ymlProperties = YamlConfigFileLoader.getProperties(environment);
        }
        return ymlProperties;
    }

    public static ConfigurableEnvironment getEnvironment() {
        try {
            final Resource resource = new ClassPathResource("application.yml");
            if (resource == null || !resource.exists()) {
                return null;
            }
            final String profiles = System.getProperty("spring.profiles.active");
            if (environment == null && profiles != null) {
                final String[] activeProfiles = profiles.split(",");
                final YamlConfigFileLoader ycfl = new YamlConfigFileLoader();
                environment = ycfl.load(activeProfiles);
                if(environment.getActiveProfiles().length == 0 && activeProfiles.length >0) {
                    environment.setActiveProfiles(activeProfiles);
                }
            }
            return environment;
        } catch (IOException e) {
            return null;
        }
    }

}
