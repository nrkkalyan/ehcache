package com.howtodoinjava.demo.cache;

import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;

import com.howtodoinjava.demo.Application;
import com.howtodoinjava.demo.yml.YmlPropertyResourceConfigurer;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.distribution.CacheManagerPeerProvider;
import net.sf.ehcache.distribution.CacheManagerPeerProviderFactory;
import net.sf.ehcache.distribution.RMICacheManagerPeerProviderFactory;

/**
 * An extension of the standard EHCache implementation that enables us to hook
 * in yml properties into the xml configuration.
 */
public class EHCacheManagerPeerProviderFactory extends CacheManagerPeerProviderFactory {
	
	
	private Logger log = LoggerFactory.getLogger(getClass());

	public static final String GROUP_ADDRESS = "ehcache.rmi.groupAddress";
	public static final String GROUP_PORT = "ehcache.rmi.groupPort";

	private static final String VARIABLE_PREFIX = "${";
	private static final String VARIABLE_SUFFIX = "}";

	private Properties mappedProps;
	
	public EHCacheManagerPeerProviderFactory() {
	}

	/**
	 * Creates a cache peer provider. Loads the constretto properties and
	 * instantiates the chosen replication strategy factory.
	 */
	@Override
	public CacheManagerPeerProvider createCachePeerProvider(CacheManager cacheManager, Properties ehcacheProps) {
		final CacheManagerPeerProviderFactory factory;
		log.info("Creating JMSCacheManagerPeerProviderFactory for ehcache cluster replication.");
		factory = new RMICacheManagerPeerProviderFactory();
		
//		mappedProps =YmlPropertyResourceConfigurer.getProperties();
		mappedProps.put(GROUP_ADDRESS, System.getProperty(GROUP_ADDRESS));
		mappedProps.put(GROUP_PORT, System.getProperty(GROUP_PORT));
		Properties modifiedEhcacheProps = applyYmlConfigProperties(mappedProps, ehcacheProps);
		return factory.createCachePeerProvider(cacheManager, modifiedEhcacheProps);
	}

 
	/**
	 * Replace variables in an original properties file with property values from
	 * yml. The properties in the original properties that do are not matched in the
	 * yml properties will be left unchanged.
	 */
	private Properties applyYmlConfigProperties(Properties ymlProperties, Properties originalProperties) {
		Properties newProperties = new Properties();
		for (Object obj : originalProperties.keySet()) {
			String key = (String) obj;
			log.debug("original property: " + key);
			String value = originalProperties.getProperty(key);
			String resolvedValue = adjustPropertyValue(value, ymlProperties);
			newProperties.put(key, resolvedValue);
			log.debug("resolvedValue: " + resolvedValue);
		}
		return newProperties;
	}

	private String adjustPropertyValue(String value, Properties ymlProperties) {
		String ymlVariable = extractYmlVariable(value);
		if (ymlVariable != null) {
			String ymlPropertyValue = ymlProperties.getProperty(ymlVariable);
			if (ymlPropertyValue == null) {
				log.warn("Value for variable {} not found in the yml properties", value);
				return value;
			}
			return ymlPropertyValue;
		}
		return value;
	}

	private static String extractYmlVariable(String value) {
		if (value.startsWith(VARIABLE_PREFIX) && value.endsWith(VARIABLE_SUFFIX)) {
			return value.substring(VARIABLE_PREFIX.length(), value.length() - VARIABLE_SUFFIX.length());
		}
		return null;
	}
 
}